/* Real Estate ERP - small UX layer on top of Unfold admin forms.
   1. Turns the grey help text under fields into a hover "i" icon next to the label.
   2. On the Property form: live "Has units / Standalone" pill and automatic upper-case code.
   Nothing here changes what is submitted to the server. */
(function () {
  "use strict";

  var BUILDING_TYPES = ["residential_building", "commercial_building"];
  var tip = null;

  function ensureTip() {
    if (!tip) {
      tip = document.createElement("div");
      tip.id = "erp-tooltip";
      tip.setAttribute("role", "tooltip");
      document.body.appendChild(tip);
    }
    return tip;
  }

  function showTip(el, text) {
    var t = ensureTip();
    t.textContent = text;
    t.classList.add("show");
    var r = el.getBoundingClientRect();
    var w = t.offsetWidth;
    var h = t.offsetHeight;
    var left = r.left + r.width / 2 - w / 2;
    left = Math.max(8, Math.min(left, window.innerWidth - w - 8));
    var top = r.top - h - 8;
    if (top < 8) {
      top = r.bottom + 8;
    }
    t.style.left = left + "px";
    t.style.top = top + "px";
  }

  function hideTip() {
    if (tip) {
      tip.classList.remove("show");
    }
  }

  function findLabel(help, form) {
    // Best case: the input points to its help text with aria-describedby.
    if (help.id) {
      var control = form.querySelector('[aria-describedby~="' + help.id + '"]');
      if (control && control.id) {
        var direct = form.querySelector('label[for="' + control.id + '"]');
        if (direct) {
          return direct;
        }
      }
    }
    // Fallback: walk up and take the closest label that comes before the help text.
    var node = help.parentElement;
    while (node && node !== form) {
      var labels = Array.prototype.slice.call(node.querySelectorAll("label[for]"));
      var before = labels.filter(function (l) {
        return l.compareDocumentPosition(help) & Node.DOCUMENT_POSITION_FOLLOWING;
      });
      if (before.length) {
        return before[before.length - 1];
      }
      node = node.parentElement;
    }
    return null;
  }

  function makeIcon(label, text) {
    if (label.querySelector(".erp-info")) {
      return;
    }
    var icon = document.createElement("span");
    icon.className = "erp-info";
    icon.tabIndex = 0;
    icon.setAttribute("role", "button");
    icon.setAttribute("aria-label", "More information");
    icon.innerHTML = '<svg viewBox="0 0 10 10" width="8" height="8" fill="currentColor" aria-hidden="true">' +
      '<circle cx="5" cy="1.7" r="1.15"/><rect x="3.9" y="3.9" width="2.2" height="5.4" rx="1"/></svg>';
    icon.addEventListener("mouseenter", function () { showTip(icon, text); });
    icon.addEventListener("mouseleave", hideTip);
    icon.addEventListener("focus", function () { showTip(icon, text); });
    icon.addEventListener("blur", hideTip);
    icon.addEventListener("click", function (e) {
      e.preventDefault();
      e.stopPropagation();
      showTip(icon, text);
    });
    // Keep the "i" on the same line as the last word of the label ("... Number (TRN) (i)"), so it never drops under the text alone.
    var textNode = null;
    for (var n = label.lastChild; n; n = n.previousSibling) {
      if (n.nodeType === 3 && n.nodeValue.trim()) { textNode = n; break; }
      if (n.nodeType === 1 && n.textContent.trim()) { break; }
    }
    if (textNode) {
      var value = textNode.nodeValue.replace(/\s+$/, "");
      var cut = value.search(/\S+$/);
      var tail = document.createElement("span");
      tail.style.whiteSpace = "nowrap";
      tail.appendChild(document.createTextNode(value.slice(cut)));
      tail.appendChild(icon);
      textNode.nodeValue = value.slice(0, cut);
      textNode.parentNode.insertBefore(tail, textNode.nextSibling);
    } else {
      label.appendChild(icon);
    }
  }

  // The same "i" icon for other scripts (the search box of the lists): window.erpMakeInfo("text") returns the icon.
  window.erpMakeInfo = function (text) {
    var holder = document.createElement("span");
    makeIcon(holder, text);
    return holder.firstChild;
  };

  function labelForControl(control, form) {
    if (control.id) {
      var direct = form.querySelector('label[for="' + control.id + '"]');
      if (direct) {
        return direct;
      }
    }
    // Fallback: closest label that comes before the control.
    var node = control.parentElement;
    while (node && node !== form) {
      var labels = Array.prototype.slice.call(node.querySelectorAll("label"));
      var before = labels.filter(function (l) {
        return l.compareDocumentPosition(control) & Node.DOCUMENT_POSITION_FOLLOWING;
      });
      if (before.length) {
        return before[before.length - 1];
      }
      node = node.parentElement;
    }
    return null;
  }

  // The server puts each field's help text on the input as data-erp-help.
  function addInfoIconsFromData(form) {
    Array.prototype.forEach.call(form.querySelectorAll("[data-erp-help]"), function (control) {
      var text = control.getAttribute("data-erp-help");
      var label = labelForControl(control, form);
      if (text && label) {
        makeIcon(label, text);
      }
    });
  }

  function addInfoIcons(form) {
    var helps = form.querySelectorAll(".help, .helptext");
    Array.prototype.forEach.call(helps, function (help) {
      if (help.getAttribute("data-erp-done") || help.closest("table")) {
        return;
      }
      var text = (help.textContent || "").replace(/\s+/g, " ").trim();
      if (!text) {
        return;
      }
      var label = findLabel(help, form);
      if (!label) {
        return;
      }
      help.setAttribute("data-erp-done", "1");
      help.classList.add("erp-help-hidden");
      makeIcon(label, text);  // the one shared way of drawing the "i" icon
    });
  }

  function markRows(form) {
    Array.prototype.forEach.call(form.querySelectorAll("label[for]"), function (label) {
      var row = label.closest(".form-row, .field-line");
      if (row) {
        row.classList.add("erp-row");
      }
    });
  }

  // ---- Property form: show only the fields that make sense --------------------------

  var NO_BUILDING_INFO_TYPES = ["warehouse", "yard", "shop", "apartment", "parking_spot"];

  function namedControls(node) {
    return node.querySelectorAll('[name]:not([type="hidden"])');
  }

  // True when the block holds no input other than this one.
  function holdsOnly(node, control) {
    var found = namedControls(node);
    for (var i = 0; i < found.length; i++) {
      if (found[i] !== control) {
        return false;
      }
    }
    return true;
  }

  function mark(node) {
    node.style.display = "none";
    node.setAttribute("data-erp-hid", "1");
  }

  // The blocks on the page that belong to one field: its input (with wrappers) and its label.
  function fieldNodes(form, control) {
    var label = control.id ? form.querySelector('label[for="' + control.id + '"]') : null;
    var anchor = control;
    while (
      anchor.parentElement &&
      anchor.parentElement !== form &&
      holdsOnly(anchor.parentElement, control)
    ) {
      anchor = anchor.parentElement;
    }
    var nodes = [anchor];
    if (label && !anchor.contains(label)) {
      var labelAnchor = label;
      while (
        labelAnchor.parentElement &&
        labelAnchor.parentElement !== form &&
        namedControls(labelAnchor.parentElement).length === 0
      ) {
        labelAnchor = labelAnchor.parentElement;
      }
      nodes.push(labelAnchor);
    }
    return nodes;
  }

  function hideFields(form, names) {
    var wanted = {};
    names.forEach(function (n) { wanted[n] = true; });
    var hidden = [];
    names.forEach(function (name) {
      var control = form.querySelector('[name="' + name + '"]');
      if (!control) {
        return;
      }
      fieldNodes(form, control).forEach(function (node) {
        mark(node);
        hidden.push(node);
      });
    });
    // Also hide any enclosing block (row, card, section with its heading) that now
    // contains nothing but hidden fields.
    hidden.forEach(function (node) {
      var parent = node.parentElement;
      while (parent && parent !== form) {
        var inside = namedControls(parent);
        var onlyHidden = inside.length > 0;
        for (var i = 0; i < inside.length; i++) {
          if (!wanted[inside[i].getAttribute("name")]) {
            onlyHidden = false;
            break;
          }
        }
        if (!onlyHidden) {
          break;
        }
        mark(parent);
        parent = parent.parentElement;
      }
    });
  }

  function propertyFormExtras(form) {
    var typeSelect = form.querySelector('[name="property_type"]');
    var ownerSelect = form.querySelector('[name="owner"]');
    var activeBox = form.querySelector('[name="is_active"]');

    // Pill next to the "Property type" label
    var badge = null;
    if (typeSelect && typeSelect.id) {
      var typeLabel = form.querySelector('label[for="' + typeSelect.id + '"]');
      if (typeLabel) {
        badge = document.createElement("span");
        typeLabel.appendChild(badge);
      }
    }

    function updateBadge() {
      if (!badge || !typeSelect) {
        return;
      }
      if (!typeSelect.value) {
        badge.className = "";
        badge.textContent = "";
        return;
      }
      var hasUnits = BUILDING_TYPES.indexOf(typeSelect.value) !== -1;
      badge.className = "erp-badge " + (hasUnits ? "is-units" : "is-standalone");
      badge.textContent = hasUnits ? "Has units" : "Standalone · no units";
    }

    // Is the selected owner the built-in "Company Owned" owner?
    function ownerIsCompany() {
      if (!ownerSelect) {
        return false;
      }
      var companyId = ownerSelect.getAttribute("data-company-owner-id");
      if (ownerSelect.value && companyId && ownerSelect.value === companyId) {
        return true;
      }
      var option = ownerSelect.options ? ownerSelect.options[ownerSelect.selectedIndex] : null;
      return !!(option && option.text && option.text.trim().toLowerCase() === "company owned");
    }

    function applyRules() {
      // Show everything we hid before, then hide what does not apply now.
      Array.prototype.forEach.call(form.querySelectorAll("[data-erp-hid]"), function (n) {
        n.style.display = "";
        n.removeAttribute("data-erp-hid");
      });

      var type = typeSelect ? typeSelect.value : "";
      var isBuilding = BUILDING_TYPES.indexOf(type) !== -1;
      var isStandalone = !!type && !isBuilding;

      var hide = [];
      if (activeBox && activeBox.checked) {
        hide.push("inactive_reason");  // a reason only matters while the property is inactive
      }
      if (NO_BUILDING_INFO_TYPES.indexOf(type) !== -1) {
        hide.push("year_built", "total_floors");
      }
      if (type !== "apartment") {
        hide.push("apartment_type", "bathrooms");
      }
      if (!isStandalone) {
        hide.push("annual_rent", "status");
      }
      hideFields(form, hide);
    }

    function refresh() {
      updateBadge();
      applyRules();
    }

    // Native change events, plus a light check every 300 ms because the searchable
    // Owner dropdown does not always fire a native change event.
    [typeSelect, ownerSelect, activeBox].forEach(function (el) {
      if (el) {
        el.addEventListener("change", refresh);
      }
    });
    var lastState = "";
    window.setInterval(function () {
      var state = [
        typeSelect ? typeSelect.value : "",
        ownerSelect ? ownerSelect.value : "",
        ownerIsCompany() ? "company" : "other",
        activeBox ? activeBox.checked : "",
      ].join("|");
      if (state !== lastState) {
        lastState = state;
        refresh();
      }
    }, 300);
    refresh();

    var code = form.querySelector('input[name="code"]');
    if (code) {
      code.addEventListener("input", function () {
        var s = code.selectionStart;
        var e = code.selectionEnd;
        code.value = code.value.toUpperCase();
        try {
          code.setSelectionRange(s, e);
        } catch (err) { /* ignore */ }
      });
    }
  }

  /* ---- Owner and tenant pages: show only the fields that apply ---- */
  function statusExtras(form) {
    var active = form.querySelector('[name="is_active"]');
    var blacklisted = form.querySelector('[name="is_blacklisted"]');
    var type = form.querySelector('[name="tenant_type"]');

    function applyRules() {
      Array.prototype.forEach.call(form.querySelectorAll("[data-erp-hid]"), function (n) {
        n.style.display = "";
        n.removeAttribute("data-erp-hid");
      });
      var hide = [];
      if (active && active.checked) {
        hide.push("inactive_reason");  // a reason only matters for an inactive record
      }
      if (blacklisted && !blacklisted.checked) {
        hide.push("blacklist_reason");
      }
      if (type) {
        if (type.value === "company") {
          hide.push("emirates_id_number", "passport_number", "date_of_birth");
        } else {
          hide.push("trade_licence_number", "authorised_signatory");
        }
      }
      hideFields(form, hide);
    }

    [active, blacklisted, type].forEach(function (el) {
      if (el) {
        el.addEventListener("change", applyRules);
      }
    });
    // The themed dropdown does not always fire a native change event, so also check regularly.
    var last = "";
    window.setInterval(function () {
      var state = [
        active ? active.checked : "",
        blacklisted ? blacklisted.checked : "",
        type ? type.value : "",
      ].join("|");
      if (state !== last) {
        last = state;
        applyRules();
      }
    }, 300);
    applyRules();
  }

  /* ---- Unsaved-changes guard: our own pop-up instead of the browser's "Leave site?" box ---- */
  function leaveGuard(form) {
    var initial = null;
    var allowLeave = false;
    var modal = null;
    var pendingHref = null;
    var lastFocus = null;

    function serialise() {
      try {
        return new URLSearchParams(new FormData(form)).toString();
      } catch (e) {
        return "";
      }
    }
    // Take the starting snapshot a moment after load, once dropdowns have finished setting up.
    setTimeout(function () { initial = serialise(); }, 600);

    function isDirty() {
      return initial !== null && serialise() !== initial;
    }

    function closeModal() {
      if (!modal) { return; }
      modal.classList.remove("is-open");
      pendingHref = null;
      if (lastFocus && lastFocus.focus) { lastFocus.focus(); }
    }

    function buildModal() {
      modal = document.createElement("div");
      modal.id = "erp-leave-modal";
      modal.innerHTML =
        '<div class="erp-leave-dialog" role="alertdialog" aria-modal="true" ' +
        'aria-labelledby="erp-leave-title" aria-describedby="erp-leave-text">' +
        '<div class="erp-leave-icon" aria-hidden="true">!</div>' +
        '<h2 id="erp-leave-title">Leave this page?</h2>' +
        '<p id="erp-leave-text">You have unsaved changes. If you leave now, they will be lost.</p>' +
        '<div class="erp-leave-actions">' +
        '<button type="button" class="erp-leave-stay">Keep editing</button>' +
        '<button type="button" class="erp-leave-go">Leave without saving</button>' +
        '</div></div>';
      document.body.appendChild(modal);
      modal.addEventListener("click", function (e) {
        if (e.target === modal) { closeModal(); }
      });
      modal.querySelector(".erp-leave-stay").addEventListener("click", closeModal);
      modal.querySelector(".erp-leave-go").addEventListener("click", function () {
        var href = pendingHref;
        allowLeave = true;
        modal.classList.remove("is-open");
        if (href) { window.location.href = href; }
      });
      modal.addEventListener("keydown", function (e) {
        if (e.key === "Escape") { e.stopPropagation(); closeModal(); }
        if (e.key === "Tab") {  // keep keyboard focus inside the pop-up
          var stay = modal.querySelector(".erp-leave-stay");
          var go = modal.querySelector(".erp-leave-go");
          if (e.shiftKey && document.activeElement === stay) { e.preventDefault(); go.focus(); }
          else if (!e.shiftKey && document.activeElement === go) { e.preventDefault(); stay.focus(); }
        }
      });
    }

    function showModal(href) {
      if (!modal) { buildModal(); }
      pendingHref = href;
      lastFocus = document.activeElement;
      modal.classList.add("is-open");
      modal.querySelector(".erp-leave-stay").focus();
    }

    // The small menu next to a dropdown (Change selected X / Add another X / View selected X /
    // Delete selected X). It opens in its own pop-up window, so the form is not being left.
    function isRelatedLink(link) {
      if (link.hasAttribute("data-popup") || link.hasAttribute("data-href-template")) { return true; }
      if (/related-widget|related-lookup/.test(link.className || "")) { return true; }
      if (link.closest('[class*="related-widget"]')) { return true; }
      var text = ((link.getAttribute("title") || "") + " " + (link.getAttribute("aria-label") || "") + " " +
        (link.textContent || "")).trim();
      return /^(change selected|add another|view selected|delete selected)\b/i.test(text);
    }

    document.addEventListener("click", function (e) {
      if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) { return; }
      var link = e.target.closest ? e.target.closest("a[href]") : null;
      if (!link || (modal && modal.contains(link))) { return; }
      var href = link.getAttribute("href");
      if (!href || href.charAt(0) === "#" || /^(javascript|mailto|tel):/i.test(href)) { return; }
      if (link.target && link.target !== "_self") { return; }
      if (link.hasAttribute("download") || link.closest(".related-widget-wrapper") || /_popup=/.test(href)) { return; }
      if (isRelatedLink(link)) { return; }  // the owner / unit "view, change, add" menu opens its own window
      if (!isDirty()) { return; }
      e.preventDefault();
      e.stopPropagation();
      showModal(link.href);
    }, true);

    form.addEventListener("submit", function () { allowLeave = true; });

    // Closing the tab, reloading or the Back button cannot be intercepted by a page:
    // for those the browser's own box is the only option.
    window.addEventListener("beforeunload", function (e) {
      if (!allowLeave && !window.__erpAllowLeave && isDirty()) {
        e.preventDefault();
        e.returnValue = "";
      }
    });
  }

  /* ---- Delete confirmation: a pop-up instead of Django's separate "Are you sure?" page ---- */
  function deleteGuard() {
    var CANCEL_TEXT = /take me back|^no,|^yes,|^cancel$/i;
    var BLOCKED = /protected related objects|would require deleting|have permission to delete|cannot delete/i;

    function el(tag, cls, text) {
      var node = document.createElement(tag);
      if (cls) { node.className = cls; }
      if (text) { node.textContent = text; }
      return node;
    }

    // Read the visible text of a node line by line (it must be in the page, even off-screen).
    function textLines(node) {
      var holder = el("div");
      holder.style.cssText = "position:absolute;left:-9999px;top:0;width:800px;";
      holder.appendChild(node);
      document.body.appendChild(holder);
      var lines = (holder.innerText || "").split("\n")
        .map(function (l) { return l.trim(); })
        .filter(function (l) { return l && !CANCEL_TEXT.test(l); });
      holder.remove();
      return lines;
    }

    function singular(word) {
      if (/ies$/i.test(word)) { return word.replace(/ies$/i, "y"); }
      if (/(ss|us)$/i.test(word)) { return word; }
      return word.replace(/s$/i, "");
    }

    function csrfToken() {
      var input = document.querySelector('input[name="csrfmiddlewaretoken"]');
      if (input) { return input.value; }
      var m = document.cookie.match(/csrftoken=([^;]+)/);
      return m ? decodeURIComponent(m[1]) : "";
    }

    // The request that really deletes: our own form, so it does not depend on Unfold's markup.
    function submitDelete(url, pairs) {
      var form = el("form");
      form.setAttribute("method", "post");
      form.setAttribute("action", url);
      form.style.display = "none";
      pairs.concat([["csrfmiddlewaretoken", csrfToken()], ["post", "yes"]]).forEach(function (kv) {
        var input = document.createElement("input");
        input.type = "hidden";
        input.name = kv[0];
        input.value = kv[1];
        form.appendChild(input);
      });
      document.body.appendChild(form);
      window.__erpAllowLeave = true;  // no "unsaved changes" box on the way out
      HTMLFormElement.prototype.submit.call(form);
    }

    function closeDialog() {
      var old = document.getElementById("erp-delete-modal");
      if (old) { old.remove(); }
    }

    // opts: title, text, sections [{heading, items[], chips}], confirmLabel, onConfirm
    function showDialog(opts) {
      closeDialog();
      var overlay = el("div");
      overlay.id = "erp-delete-modal";
      var dlg = el("div", "erp-leave-dialog erp-del-dialog");
      dlg.setAttribute("role", "alertdialog");
      dlg.setAttribute("aria-modal", "true");
      dlg.setAttribute("aria-label", opts.title);
      dlg.appendChild(el("div", "erp-leave-icon erp-del-icon", "!"));
      dlg.appendChild(el("h2", "", opts.title));
      if (opts.text) { dlg.appendChild(el("p", "", opts.text)); }

      (opts.sections || []).forEach(function (sec) {
        if (!sec.items.length) { return; }
        var box = el("div", "erp-del-section");
        if (sec.heading) { box.appendChild(el("div", "erp-del-heading", sec.heading)); }
        var list = el("ul", sec.chips ? "erp-del-chips" : "erp-del-list");
        sec.items.forEach(function (item) { list.appendChild(el("li", "", item)); });
        box.appendChild(list);
        dlg.appendChild(box);
      });

      var actions = el("div", "erp-leave-actions");
      var cancel = el("button", "erp-leave-stay", opts.confirmLabel ? "Cancel" : "Close");
      cancel.type = "button";
      actions.appendChild(cancel);
      var go = null;
      if (opts.confirmLabel) {
        go = el("button", "erp-del-go", opts.confirmLabel);
        go.type = "button";
        actions.appendChild(go);
      }
      dlg.appendChild(actions);
      overlay.appendChild(dlg);
      document.body.appendChild(overlay);
      overlay.classList.add("is-open");
      cancel.focus();

      cancel.addEventListener("click", closeDialog);
      overlay.addEventListener("click", function (e) { if (e.target === overlay) { closeDialog(); } });
      overlay.addEventListener("keydown", function (e) {
        if (e.key === "Escape") { e.stopPropagation(); closeDialog(); }
        if (e.key === "Tab" && go) {
          if (e.shiftKey && document.activeElement === cancel) { e.preventDefault(); go.focus(); }
          else if (!e.shiftKey && document.activeElement === go) { e.preventDefault(); cancel.focus(); }
        }
      });
      if (go) {
        go.addEventListener("click", function () {
          go.disabled = true;
          go.textContent = "Deleting...";
          opts.onConfirm();
        });
      }
    }

    // opts: url, body (POST data, optional), postUrl, pairs, names, count, noun, fallback
    function confirmDelete(opts) {
      var options = { credentials: "same-origin", headers: { "X-Requested-With": "XMLHttpRequest" } };
      if (opts.body) { options.method = "POST"; options.body = opts.body; }
      fetch(opts.url, options).then(function (response) {
        if (response.redirected && /login/.test(response.url)) { throw new Error("login"); }
        return response.text();
      }).then(function (html) {
        var doc = new DOMParser().parseFromString(html, "text/html");
        var pageText = doc.body ? doc.body.textContent : "";
        var area = doc.querySelector("main") || doc.querySelector("#content-main") || doc.querySelector("#content");
        var lines = area ? textLines(document.importNode(area, true)) : [];

        // Django itself says it cannot delete (protected related records / no permission).
        if (BLOCKED.test(area ? area.textContent : pageText)) {
          var builtIn = /built-in account/i.test(area ? area.textContent : pageText) ||
            (opts.names || []).some(function (n) { return /company owned/i.test(String(n)); });
          if (builtIn) {  // the built-in owner: a clear, friendly explanation
            showDialog({
              title: "Company Owned cannot be deleted",
              text: "Company Owned is a built-in account. It represents the properties owned by the company " +
                    "itself and is required by the system, so it cannot be deleted.",
              sections: (opts.names || []).length > 1
                ? [{ heading: "", items: ["Untick Company Owned and try again to delete the others."] }] : []
            });
            return;
          }
          // The reasons are the items of Django's list: either whole sentences written by the app (shown as
          // the explanation) or the names of linked records that cannot be removed.
          var seen = {}, reasons = [];
          Array.prototype.forEach.call(area ? area.querySelectorAll("li") : [], function (li) {
            if (li.querySelector("li")) { return; }
            var t = (li.textContent || "").replace(/\s+/g, " ").trim();
            if (t && !seen[t]) { seen[t] = true; reasons.push(t); }
          });
          var sentences = reasons.filter(function (t) { return t.length > 40 && /[.!]$/.test(t); });
          var linked = reasons.filter(function (t) { return sentences.indexOf(t) < 0; });
          var protectedCase = /protected related objects|would require deleting/i.test(area ? area.textContent : pageText);
          var what = (opts.noun || "record");
          var intro = sentences.length ? sentences.join(" ")
            : (protectedCase
              ? "This " + singular(what) + " cannot be deleted because other records depend on it. Remove or change these first:"
              : "This " + singular(what) + " cannot be deleted because it is linked to records that your account is not allowed to delete:");
          showDialog({
            title: "This cannot be deleted",
            text: intro,
            sections: sentences.length ? [] : [{ heading: "", items: linked.slice(0, 8) }]
          });
          return;
        }

        // Read Django's own list of what will be deleted; fall back to the names we already know.
        var low = lines.map(function (l) { return l.toLowerCase(); });
        var iSummary = low.indexOf("summary");
        var iObjects = low.indexOf("objects");
        var summary = [], objects = [], noun = opts.noun || "", count = opts.count, noundFromPage = false;
        if (iObjects > -1) {
          summary = iSummary > -1 ? lines.slice(iSummary + 1, iObjects) : [];
          objects = lines.slice(iObjects + 1);
          var text = lines.join("\n");
          var found = (text.match(/delete the selected ([^?\n]+)\?/i) || [])[1] ||
                      (text.match(/delete the ([^"“”'?\n]+?)\s*["“”']/i) || [])[1];
          if (found) { noun = found.trim(); noundFromPage = true; }
          var n = parseInt(((summary[0] || "").match(/:\s*(\d+)/) || [])[1], 10);
          if (n) { count = n; }
        }
        if (!objects.length) { objects = opts.names; }
        if (!noundFromPage && count <= 1) { noun = singular(noun); }  // "properties" -> "property"

        // "Property: Sharjah 3 (SHJ3)" -> name "Sharjah 3 (SHJ3)"
        var first = (objects[0] || "").replace(/^[^:]{1,40}:\s*/, "");
        var related = objects.length > 1;
        var title, message;
        if (count > 1) {
          title = "Delete " + count + " " + (noun || "records") + "?";
          message = "These " + count + " " + (noun || "records") + " will be permanently deleted" +
                    (related ? ", together with the related items listed below" : "") +
                    ". This cannot be undone.";
        } else {
          title = noun && first ? "Delete " + noun + " “" + first + "”?" : "Delete this record?";
          message = related
            ? "This " + (noun || "record") + " and the related items listed below will be permanently deleted. This cannot be undone."
            : "This " + (noun || "record") + " will be permanently deleted. This cannot be undone.";
        }
        showDialog({
          title: title,
          text: message,
          sections: [
            { heading: "Summary", items: summary.length > 1 ? summary : [], chips: true },
            { heading: count > 1 || related ? "Will be deleted" : "", items: count > 1 || related ? objects : [] }
          ],
          confirmLabel: "Yes, delete",
          onConfirm: function () { submitDelete(opts.postUrl, opts.pairs); }
        });
      }).catch(function () { opts.fallback(); });
    }

    // Delete button inside a record
    document.addEventListener("click", function (e) {
      if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) { return; }
      var link = e.target.closest ? e.target.closest("a[href]") : null;
      if (!link) { return; }
      if (!/\/delete\/?$/.test(link.pathname || "") || (link.target && link.target !== "_self")) { return; }
      if (link.closest(".related-widget-wrapper") || /_popup=/.test(link.search)) { return; }
      e.preventDefault();
      e.stopPropagation();
      var heading = document.querySelector("h1");
      confirmDelete({
        url: link.href, postUrl: link.href, pairs: [],
        names: heading && heading.textContent.trim() ? [heading.textContent.trim()] : [],
        count: 1, noun: "",
        fallback: function () { window.location.href = link.href; }
      });
    }, true);

    // "Delete selected ..." from a list page
    document.addEventListener("submit", function (e) {
      var form = e.target;
      if (!form || form.tagName !== "FORM" || form.dataset.erpBypass) { return; }
      var data;
      try { data = new FormData(form); } catch (err) { return; }
      if (data.get("action") !== "delete_selected" || data.get("post")) { return; }
      var ticked = Array.prototype.slice.call(form.querySelectorAll('input[name="_selected_action"]:checked'));
      if (!ticked.length) { return; }  // nothing ticked: Django explains it
      e.preventDefault();
      e.stopPropagation();

      var names = ticked.map(function (box) {
        var row = box.closest("tr");
        var best = "";
        if (row) {
          Array.prototype.forEach.call(row.querySelectorAll("a"), function (a) {
            var t = a.textContent.trim();
            if (t.length > best.length) { best = t; }
          });
        }
        return best || "Selected item";
      });
      var select = form.querySelector('select[name="action"]');
      var label = select && select.selectedOptions[0] ? select.selectedOptions[0].textContent : "";
      var noun = (label.match(/delete selected (.+)/i) || [])[1] || "";

      var pairs = [];
      data.forEach(function (value, key) {
        if (key !== "csrfmiddlewaretoken" && key !== "post" && key !== "index" && typeof value === "string") {
          pairs.push([key, value]);
        }
      });
      var target = new URL(form.getAttribute("action") || window.location.href, window.location.href).href;
      confirmDelete({
        url: target, body: data, postUrl: target, pairs: pairs,
        names: names, count: names.length, noun: noun,
        fallback: function () { form.dataset.erpBypass = "1"; HTMLFormElement.prototype.submit.call(form); }
      });
    }, true);
  }

  // Sidebar sections: remember what the person opened or closed (Unfold forgets on every page load).
  // Default is open; the section holding the current page is always open.
  function sidebarMemory() {
    var KEY = "erp-nav-closed";
    function load() {
      try { return JSON.parse(localStorage.getItem(KEY) || "{}"); } catch (e) { return {}; }
    }
    function save(state) {
      try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) { /* storage blocked */ }
    }
    function apply() {
      if (!window.Alpine || !window.Alpine.$data) { return; }
      var state = load();
      document.querySelectorAll("h2.cursor-pointer, h2[x-on\\:click]").forEach(function (h) {
        var box = h.closest("[x-data]");
        var title = (h.textContent || "").trim();
        if (!box || !title || h.dataset.erpNav) { return; }
        h.dataset.erpNav = "1";
        var data = window.Alpine.$data(box);
        if (!data || typeof data.navigationOpen === "undefined") { return; }
        var hasActive = !!box.querySelector("a[aria-current], li.active, a.font-semibold, a.bg-base-100, [class*='active']");
        data.navigationOpen = hasActive ? true : state[title] !== true;
        h.addEventListener("click", function () {
          setTimeout(function () {
            var s2 = load();
            s2[title] = !data.navigationOpen;  // true = closed
            save(s2);
          }, 0);
        });
      });
    }
    document.addEventListener("alpine:initialized", apply);
    setTimeout(apply, 0);
    setTimeout(apply, 300);
  }

  // Pop-up notifications: the server hands over Django's messages as window.__erpToasts.
  var TOAST_STYLE = {
    success: { title: "Success", icon: "M5 13l4 4L19 7" },
    error: { title: "Error", icon: "M6 6l12 12M18 6L6 18" },
    warning: { title: "Warning", icon: "M12 8v5m0 3h.01" },
    info: { title: "Information", icon: "M12 11v5m0-8h.01" }
  };

  function toastHost() {
    var host = document.getElementById("erp-toasts");
    if (!host) {
      host = document.createElement("div");
      host.id = "erp-toasts";
      host.setAttribute("aria-live", "polite");
      document.body.appendChild(host);
    }
    return host;
  }

  function showToast(level, parts, heading) {
    var style = TOAST_STYLE[level] || TOAST_STYLE.info;
    var kind = TOAST_STYLE[level] ? level : "info";
    var toast = document.createElement("div");
    toast.className = "erp-toast erp-toast-" + kind;
    toast.setAttribute("role", kind === "error" ? "alert" : "status");

    var icon = document.createElement("div");
    icon.className = "erp-toast-icon";
    icon.innerHTML = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" ' +
      'stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="' + style.icon + '"/></svg>';

    var body = document.createElement("div");
    body.className = "erp-toast-body";
    var title = document.createElement("div");
    title.className = "erp-toast-title";
    title.textContent = heading || style.title;
    var message = document.createElement("div");
    message.className = "erp-toast-text";
    (parts || []).forEach(function (part) {
      if (part.href) {
        var link = document.createElement("a");
        link.href = part.href;
        link.textContent = part.t;
        link.className = "erp-toast-link";
        message.appendChild(link);
      } else {
        message.appendChild(document.createTextNode(part.t));
      }
    });
    body.appendChild(title);
    body.appendChild(message);

    var close = document.createElement("button");
    close.type = "button";
    close.className = "erp-toast-close";
    close.setAttribute("aria-label", "Close");
    close.innerHTML = "&times;";

    var bar = document.createElement("div");
    bar.className = "erp-toast-bar";

    toast.appendChild(icon);
    toast.appendChild(body);
    toast.appendChild(close);
    toast.appendChild(bar);
    toastHost().appendChild(toast);

    // Success and information fade away by themselves; warnings and errors stay longer.
    var base = (window.__erpToastSeconds || 5) * 1000;
    var total = kind === "success" || kind === "info" ? base : base * 2;
    var left = total;
    var started = Date.now();
    var timer = null;
    bar.style.animationDuration = total + "ms";

    function dismiss() {
      clearTimeout(timer);
      toast.classList.add("is-leaving");
      setTimeout(function () { toast.remove(); }, 220);
    }
    function start() {
      started = Date.now();
      bar.style.animationPlayState = "running";
      timer = setTimeout(dismiss, left);
    }
    function pause() {
      clearTimeout(timer);
      left -= Date.now() - started;
      bar.style.animationPlayState = "paused";
    }
    toast.addEventListener("mouseenter", pause);
    toast.addEventListener("mouseleave", start);
    close.addEventListener("click", dismiss);
    requestAnimationFrame(function () { toast.classList.add("is-in"); });
    start();
  }

  function showToasts() {
    var list = window.__erpToasts;
    if (!list || !list.length || !document.body) { return; }
    window.__erpToasts = [];
    list.forEach(function (item, i) {
      setTimeout(function () { showToast(item.level, item.parts, item.title); }, i * 150);
    });
  }
  window.erpShowToasts = showToasts;

  // File fields (photos, documents): View / Edit / Delete buttons. Delete only ticks a hidden
  // "clear" box; the file is really removed when the form is saved.
  function fileWidgets() {
    var lightbox = null;
    function openLightbox(src) {
      if (!lightbox) {
        lightbox = document.createElement("div");
        lightbox.id = "erp-lightbox";
        lightbox.innerHTML = '<button type="button" class="erp-lightbox-close" aria-label="Close">&times;</button><img alt="">';
        document.body.appendChild(lightbox);
        lightbox.addEventListener("click", function () { lightbox.classList.remove("is-open"); });
        document.addEventListener("keydown", function (e) {
          if (e.key === "Escape") { lightbox.classList.remove("is-open"); }
        });
      }
      lightbox.querySelector("img").src = src;
      lightbox.classList.add("is-open");
    }

    function parts(box) {
      return {
        input: box.querySelector(".erp-file-input"),
        clear: box.querySelector(".erp-file-clear"),
        view: box.querySelector("[data-erp-view]"),
        edit: box.querySelector("[data-erp-edit]"),
        del: box.querySelector("[data-erp-delete]"),
        name: box.querySelector(".erp-file-name"),
        note: box.querySelector(".erp-file-note"),
        img: box.querySelector(".erp-file-preview img")
      };
    }

    function label(btn, text) {
      var l = btn.querySelector(".erp-fbtn-label");
      if (l) { l.textContent = text; }
      btn.title = text;
    }

    function setNote(p, text) {
      p.note.hidden = !text;
      p.note.textContent = text || "";
    }

    function refresh(box) {
      var p = parts(box);
      var hasInitial = !!p.clear || !!p.view;
      var chosen = p.input.files && p.input.files.length ? p.input.files[0] : null;
      var deleted = !!(p.clear && p.clear.checked);
      box.classList.toggle("is-deleted", deleted);
      if (p.del) {
        if (hasInitial) {
          label(p.del, deleted ? "Undo delete" : "Delete");
          p.del.hidden = false;
        } else {
          p.del.hidden = !chosen;
        }
      }
      if (p.view) { p.view.hidden = deleted; }
      if (!hasInitial && p.name) {
        p.name.textContent = chosen ? chosen.name : "No file";
        p.name.classList.toggle("erp-file-empty", !chosen);
      }
      if (deleted) {
        setNote(p, "Will be deleted when you save.");
      } else if (chosen) {
        setNote(p, (box.getAttribute("data-crop") === "1" ? "New picture ready. It is saved when you press Save." : "New file selected. It is saved when you press Save."));
      } else {
        setNote(p, "");
      }
    }

    document.addEventListener("click", function (e) {
      var target = e.target.closest ? e.target.closest("[data-erp-view],[data-erp-edit],[data-erp-delete]") : null;
      if (!target) { return; }
      var box = target.closest("[data-erp-file]");
      if (!box) { return; }
      var p = parts(box);
      if (target.hasAttribute("data-erp-view")) {
        if (box.getAttribute("data-image") === "1") {
          e.preventDefault();
          openLightbox(target.getAttribute("href"));
        }
        return;  // documents (PDF) open in a new tab
      }
      e.preventDefault();
      if (target.hasAttribute("data-erp-edit")) {
        p.input.click();
        return;
      }
      // Delete / Undo / Remove
      if (p.clear) {
        p.clear.checked = !p.clear.checked;
        if (p.clear.checked) { p.input.value = ""; }
      } else {
        p.input.value = "";
      }
      if (p.img && p.img.getAttribute("data-original")) { p.img.src = p.img.getAttribute("data-original"); }
      else if (p.img && p.img.parentNode.getAttribute("data-made")) { p.img.parentNode.hidden = true; }
      refresh(box);
    });

    // ---- Picture editor: opens when a photo / logo is chosen, so it can be moved, zoomed and cropped ----
    var OUT_MAX = 800;  // saved pictures are at most this many pixels wide and high

    function openCropper(file, round, done, cancel) {
      var url = URL.createObjectURL(file);
      var img = new Image();
      img.onerror = function () { URL.revokeObjectURL(url); done(null); };  // not readable here: use it as it is
      img.onload = function () {
        var W = img.naturalWidth, H = img.naturalHeight;
        var box = Math.max(200, Math.min(320, window.innerWidth - 80));
        var scale = 1, minScale = 1, maxScale = 1, x = 0, y = 0;  // x, y: top-left of the picture inside the frame
        var wrap = document.createElement("div");
        wrap.className = "erp-crop-backdrop";
        wrap.innerHTML =
          '<div class="erp-crop-dialog" role="dialog" aria-modal="true" aria-label="Adjust picture">' +
          '<h3 class="erp-crop-title">Adjust picture</h3>' +
          '<p class="erp-crop-hint">Drag the picture to move it. Use the slider to zoom.</p>' +
          '<div class="erp-crop-frame' + (round ? ' is-round' : '') + '" style="width:' + box + 'px;height:' + box + 'px">' +
          '<canvas width="' + box + '" height="' + box + '"></canvas><span class="erp-crop-ring"></span></div>' +
          '<input type="range" class="erp-crop-zoom" min="0" max="100" value="0" step="0.5" aria-label="Zoom">' +
          '<div class="erp-crop-buttons"><button type="button" class="erp-fbtn" data-crop-cancel>Cancel</button>' +
          '<button type="button" class="erp-fbtn erp-fbtn-primary" data-crop-ok>Use this picture</button></div></div>';
        document.body.appendChild(wrap);
        var canvas = wrap.querySelector("canvas");
        var ctx = canvas.getContext("2d");
        var zoom = wrap.querySelector(".erp-crop-zoom");

        function clamp() {
          x = Math.min(0, Math.max(box - W * scale, x));
          y = Math.min(0, Math.max(box - H * scale, y));
        }
        function draw() {
          clamp();
          ctx.clearRect(0, 0, box, box);
          ctx.drawImage(img, x, y, W * scale, H * scale);
        }
        function setScale(next) {  // zoom around the middle of the frame
          next = Math.min(maxScale, Math.max(minScale, next));
          var cx = (box / 2 - x) / scale, cy = (box / 2 - y) / scale;
          scale = next;
          x = box / 2 - cx * scale;
          y = box / 2 - cy * scale;
          zoom.value = maxScale > minScale ? ((scale - minScale) / (maxScale - minScale)) * 100 : 0;
          draw();
        }
        minScale = Math.max(box / W, box / H);  // the picture always fills the frame
        maxScale = minScale * 4;
        scale = minScale;
        x = (box - W * scale) / 2;
        y = (box - H * scale) / 2;
        draw();

        zoom.addEventListener("input", function () {
          setScale(minScale + (maxScale - minScale) * (parseFloat(zoom.value) / 100));
        });
        canvas.addEventListener("wheel", function (ev) {
          ev.preventDefault();
          setScale(scale * (ev.deltaY < 0 ? 1.08 : 1 / 1.08));
        }, { passive: false });
        var drag = null;
        canvas.addEventListener("pointerdown", function (ev) {
          drag = { px: ev.clientX, py: ev.clientY, x: x, y: y };
          canvas.setPointerCapture(ev.pointerId);
          wrap.classList.add("is-dragging");
        });
        canvas.addEventListener("pointermove", function (ev) {
          if (!drag) { return; }
          x = drag.x + (ev.clientX - drag.px);
          y = drag.y + (ev.clientY - drag.py);
          draw();
        });
        function stopDrag() { drag = null; wrap.classList.remove("is-dragging"); }
        canvas.addEventListener("pointerup", stopDrag);
        canvas.addEventListener("pointercancel", stopDrag);

        function close() {
          document.removeEventListener("keydown", onKey, true);
          wrap.remove();
          URL.revokeObjectURL(url);
        }
        function onKey(ev) {
          if (ev.key === "Escape") { ev.stopPropagation(); close(); cancel(); }
        }
        document.addEventListener("keydown", onKey, true);
        wrap.addEventListener("click", function (ev) {
          if (ev.target.closest("[data-crop-cancel]")) { close(); cancel(); }
          if (ev.target.closest("[data-crop-ok]")) {
            var side = Math.round(Math.min(OUT_MAX, box / scale));  // the part of the original inside the frame
            var out = document.createElement("canvas");
            out.width = side;
            out.height = side;
            out.getContext("2d").drawImage(img, -x / scale, -y / scale, box / scale, box / scale, 0, 0, side, side);
            var png = file.type === "image/png";
            out.toBlob(function (blob) {
              close();
              if (!blob) { done(null); return; }
              var base = (file.name || "picture").replace(/\.[^.]*$/, "");
              done(new File([blob], base + (png ? ".png" : ".jpg"), { type: png ? "image/png" : "image/jpeg" }));
            }, png ? "image/png" : "image/jpeg", 0.92);
          }
        });
        wrap.querySelector("[data-crop-ok]").focus();
      };
      img.src = url;
    }

    function showPreview(box, p, src) {
      if (box.getAttribute("data-crop") !== "1") { return; }
      if (!p.img) {  // an empty picture field has no preview yet: make one
        var holder = document.createElement("div");
        holder.className = "erp-file-preview" + (box.getAttribute("data-round") === "1" ? " erp-file-round" : "");
        holder.setAttribute("data-made", "1");
        var made = document.createElement("img");
        made.alt = "";
        holder.appendChild(made);
        box.insertBefore(holder, box.querySelector(".erp-file-row"));
        p.img = made;
      }
      p.img.parentNode.hidden = false;
      if (!p.img.getAttribute("data-original") && !p.img.parentNode.getAttribute("data-made")) {
        p.img.setAttribute("data-original", p.img.src);
      }
      p.img.src = src;
    }

    document.addEventListener("change", function (e) {
      if (!e.target.classList || !e.target.classList.contains("erp-file-input")) { return; }
      var input = e.target;
      var box = input.closest("[data-erp-file]");
      var p = parts(box);
      var file = input.files && input.files[0];
      if (p.clear && file) { p.clear.checked = false; }  // a new file replaces the delete
      var isPicture = file && /^image\//.test(file.type);
      if (isPicture && box.getAttribute("data-crop") === "1" && window.File && window.DataTransfer) {
        openCropper(file, box.getAttribute("data-round") === "1", function (edited) {
          if (edited) {
            var list = new DataTransfer();
            list.items.add(edited);
            input.files = list.files;
            showPreview(box, p, URL.createObjectURL(edited));
          } else {
            showPreview(box, p, URL.createObjectURL(file));  // could not be edited: keep it as chosen
          }
          refresh(box);
        }, function () {
          input.value = "";  // cancelled: nothing is chosen
          refresh(box);
        });
        return;
      }
      if (isPicture && p.img) {
        if (!p.img.getAttribute("data-original")) { p.img.setAttribute("data-original", p.img.src); }
        p.img.src = URL.createObjectURL(file);
      }
      refresh(box);
    });
  }

  // Dropdowns: every normal <select> in the app is shown as our own styled, animated dropdown.
  // The real <select> stays in the page (hidden), so forms, validation and other scripts keep
  // working: choosing an option sets its value and fires a normal "change" event.
  function customSelects() {
    var SEARCH_FROM = 9;  // show a search box when there are more options than this
    var CHECK = '<svg class="erp-opt-check" viewBox="0 0 24 24" width="16" height="16" fill="none" ' +
      'stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">' +
      '<path d="M5 13l4 4L19 7"/></svg>';
    var CHEVRON = '<svg class="erp-select-chevron" viewBox="0 0 24 24" width="18" height="18" fill="none" ' +
      'stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
      '<path d="M6 9l6 6 6-6"/></svg>';
    var uid = 0;
    var current = null;  // the open dropdown: {select, trigger, panel, list, search, items, active}

    function eligible(sel) {
      if (sel.dataset.erpSelect || sel.multiple || sel.size > 1) { return false; }
      if (sel.hasAttribute("data-erp-native")) { return false; }
      if (/__prefix__/.test((sel.name || "") + (sel.id || ""))) { return false; }
      if (sel.closest(".empty-form, .select2, .select2-container")) { return false; }
      if (sel.classList.contains("select2-hidden-accessible")) { return false; }
      if (/autocomplete|select2|tom-select/i.test(sel.className)) { return false; }
      var attrs = sel.attributes;  // searchable (ajax) dropdowns have their own widget
      for (var i = 0; i < attrs.length; i += 1) {
        if (/^data-(ajax|autocomplete|tom|select2)/i.test(attrs[i].name)) { return false; }
      }
      return true;
    }

    function isPlaceholder(option) {
      return !option || option.value === "" && /^[-–—\s]*$/.test(option.text);
    }

    function sync(sel) {
      var trigger = sel._erpTrigger;
      if (!trigger) { return; }
      var option = sel.options[sel.selectedIndex];
      var label = trigger.querySelector(".erp-select-label");
      var empty = isPlaceholder(option);
      label.textContent = empty ? "Select an option" : option.text;
      trigger.classList.toggle("is-placeholder", empty);
      trigger.disabled = sel.disabled;
      trigger.classList.toggle("is-invalid", sel.getAttribute("aria-invalid") === "true");
    }

    function enhance(sel) {
      if (!eligible(sel)) { return; }
      sel.dataset.erpSelect = "1";
      var width = sel.offsetWidth;
      var wrap = document.createElement("div");
      wrap.className = "erp-select";
      if (width > 0) {
        wrap.style.width = width + "px";
        wrap.style.maxWidth = "100%";
      } else {
        wrap.classList.add("erp-select-fluid");  // inside a hidden tab: measured later by CSS
      }
      var trigger = document.createElement("button");
      trigger.type = "button";
      trigger.className = "erp-select-trigger";
      trigger.setAttribute("aria-haspopup", "listbox");
      trigger.setAttribute("aria-expanded", "false");
      trigger.innerHTML = '<span class="erp-select-label"></span>' + CHEVRON;
      var labelEl = sel.id ? document.querySelector('label[for="' + sel.id + '"]') : null;
      if (labelEl) {
        if (!labelEl.id) { labelEl.id = "erp-label-" + (++uid); }
        trigger.setAttribute("aria-labelledby", labelEl.id);
      }
      var holder = sel.parentNode;
      holder.insertBefore(wrap, sel);
      wrap.appendChild(sel);
      wrap.appendChild(trigger);
      // The theme draws its own little arrow next to a select: hide it, ours replaces it.
      Array.prototype.forEach.call(holder.children, function (sibling) {
        if (sibling !== wrap && sibling.matches &&
            sibling.matches('[class*="material-symbols"], svg, .select-arrow')) {
          sibling.style.display = "none";
        }
      });
      sel.classList.add("erp-select-native");
      sel.tabIndex = -1;
      sel.setAttribute("aria-hidden", "true");
      sel._erpTrigger = trigger;

      trigger.addEventListener("click", function () {
        if (current && current.select === sel) { closePanel(); } else { openPanel(sel); }
      });
      trigger.addEventListener("keydown", function (e) {
        if (current) { return; }  // the open dropdown handles keys itself
        if (e.key === "ArrowDown" || e.key === "ArrowUp" || e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          openPanel(sel);
        }
      });
      sel.addEventListener("focus", function () { trigger.focus(); });  // label click / validation
      sel.addEventListener("change", function () { sync(sel); });
      new MutationObserver(function () { sync(sel); }).observe(sel, {
        childList: true, subtree: true, attributes: true, attributeFilter: ["disabled", "aria-invalid"]
      });
      sync(sel);
    }

    function enhanceAll(root) {
      if (root.matches && root.matches("select")) { enhance(root); }
      if (root.querySelectorAll) {
        Array.prototype.forEach.call(root.querySelectorAll("select"), enhance);
      }
    }

    // ---- the open dropdown ----------------------------------------------------------------
    function buildItems(sel, list) {
      var items = [];
      function addOption(option, group) {
        var li = document.createElement("li");
        li.className = "erp-opt";
        li.setAttribute("role", "option");
        li.id = "erp-opt-" + (++uid);
        li.dataset.index = String(option.index);
        var selected = option.index === sel.selectedIndex;
        li.setAttribute("aria-selected", selected ? "true" : "false");
        if (selected) { li.classList.add("is-selected"); }
        if (option.disabled || (group && group.disabled)) {
          li.classList.add("is-disabled");
          li.setAttribute("aria-disabled", "true");
        }
        var text = document.createElement("span");
        text.className = "erp-opt-text";
        var placeholder = isPlaceholder(option);
        text.textContent = placeholder ? "None" : option.text;
        if (placeholder) { li.classList.add("is-none"); }
        li.appendChild(text);
        li.insertAdjacentHTML("beforeend", CHECK);
        list.appendChild(li);
        items.push(li);
      }
      Array.prototype.forEach.call(sel.children, function (child) {
        if (child.tagName === "OPTGROUP") {
          var head = document.createElement("li");
          head.className = "erp-opt-group";
          head.setAttribute("role", "presentation");
          head.textContent = child.label;
          list.appendChild(head);
          Array.prototype.forEach.call(child.children, function (o) { addOption(o, child); });
        } else if (child.tagName === "OPTION") {
          addOption(child, null);
        }
      });
      return items;
    }

    function place() {
      if (!current) { return; }
      var rect = current.trigger.getBoundingClientRect();
      var panel = current.panel;
      var gap = 6;
      var vh = window.innerHeight;
      var below = vh - rect.bottom - gap - 8;
      var above = rect.top - gap - 8;
      panel.style.minWidth = rect.width + "px";
      panel.style.maxWidth = Math.max(rect.width, Math.min(480, window.innerWidth - 16)) + "px";
      current.list.style.maxHeight = "0px";  // measure the natural height of the search box etc.
      var chrome = panel.offsetHeight;
      var natural = current.list.scrollHeight + chrome;
      var openUp = natural > below && above > below;
      var room = Math.max(120, openUp ? above : below);
      current.list.style.maxHeight = Math.min(280, room - chrome) + "px";
      var height = panel.offsetHeight;
      var left = Math.min(Math.max(8, rect.left), window.innerWidth - panel.offsetWidth - 8);
      panel.style.left = left + "px";
      panel.style.top = (openUp ? rect.top - gap - height : rect.bottom + gap) + "px";
      panel.classList.toggle("is-up", openUp);
    }

    function setActive(index, scroll) {
      if (!current) { return; }
      var visible = current.items.filter(function (li) { return !li.hidden; });
      if (!visible.length) { current.active = null; return; }
      var li = visible[Math.max(0, Math.min(index, visible.length - 1))];
      if (current.active) { current.active.classList.remove("is-active"); }
      current.active = li;
      li.classList.add("is-active");
      current.trigger.setAttribute("aria-activedescendant", li.id);
      if (scroll !== false) { li.scrollIntoView({ block: "nearest" }); }
    }

    function move(step) {
      if (!current) { return; }
      var visible = current.items.filter(function (li) {
        return !li.hidden && !li.classList.contains("is-disabled");
      });
      if (!visible.length) { return; }
      var at = visible.indexOf(current.active);
      var next = at === -1 ? (step > 0 ? 0 : visible.length - 1) : at + step;
      next = Math.max(0, Math.min(next, visible.length - 1));
      var all = current.items.filter(function (li) { return !li.hidden; });
      setActive(all.indexOf(visible[next]));
    }

    function choose(li) {
      if (!current || !li || li.classList.contains("is-disabled")) { return; }
      var sel = current.select;
      var index = parseInt(li.dataset.index, 10);
      var changed = sel.selectedIndex !== index;
      sel.selectedIndex = index;
      var trigger = current.trigger;
      closePanel();
      sync(sel);
      if (changed) {
        sel.dispatchEvent(new Event("input", { bubbles: true }));
        sel.dispatchEvent(new Event("change", { bubbles: true }));
      }
      trigger.focus();
    }

    function openPanel(sel) {
      closePanel(true);
      var trigger = sel._erpTrigger;
      if (!trigger || trigger.disabled) { return; }
      var panel = document.createElement("div");
      panel.className = "erp-select-panel";
      var search = null;
      if (sel.options.length > SEARCH_FROM) {
        search = document.createElement("input");
        search.type = "text";
        search.className = "erp-select-search";
        search.placeholder = "Search...";
        search.setAttribute("aria-label", "Search options");
        search.autocomplete = "off";
        panel.appendChild(search);
      }
      var list = document.createElement("ul");
      list.className = "erp-select-list";
      list.setAttribute("role", "listbox");
      panel.appendChild(list);
      var empty = document.createElement("div");
      empty.className = "erp-select-empty";
      empty.textContent = "No matches";
      empty.hidden = true;
      panel.appendChild(empty);
      var items = buildItems(sel, list);
      document.body.appendChild(panel);
      current = { select: sel, trigger: trigger, panel: panel, list: list, search: search,
                  items: items, empty: empty, active: null, typed: "", typedAt: 0 };
      trigger.setAttribute("aria-expanded", "true");
      trigger.classList.add("is-open");
      place();
      var selected = items.filter(function (li) { return li.classList.contains("is-selected"); })[0];
      setActive(selected ? items.indexOf(selected) : 0);
      requestAnimationFrame(function () { panel.classList.add("is-open"); });
      if (search) { search.focus(); }

      list.addEventListener("mousemove", function (e) {
        var li = e.target.closest ? e.target.closest(".erp-opt") : null;
        if (li && li !== current.active && !li.classList.contains("is-disabled")) {
          setActive(current.items.filter(function (x) { return !x.hidden; }).indexOf(li), false);
        }
      });
      list.addEventListener("click", function (e) {
        var li = e.target.closest ? e.target.closest(".erp-opt") : null;
        if (li) { choose(li); }
      });
      if (search) {
        search.addEventListener("input", function () {
          var q = search.value.trim().toLowerCase();
          var shown = 0;
          current.items.forEach(function (li) {
            var match = !q || li.textContent.toLowerCase().indexOf(q) !== -1;
            li.hidden = !match;
            if (match) { shown += 1; }
          });
          Array.prototype.forEach.call(list.querySelectorAll(".erp-opt-group"), function (g) {
            g.hidden = !!q;
          });
          current.empty.hidden = shown > 0;
          setActive(0);
          place();
        });
      }
    }

    function closePanel(immediate) {
      if (!current) { return; }
      var c = current;
      current = null;
      c.trigger.setAttribute("aria-expanded", "false");
      c.trigger.removeAttribute("aria-activedescendant");
      c.trigger.classList.remove("is-open");
      c.panel.classList.remove("is-open");
      if (immediate) { c.panel.remove(); } else { setTimeout(function () { c.panel.remove(); }, 160); }
    }

    document.addEventListener("keydown", function (e) {
      if (!current) { return; }
      var key = e.key;
      if (key === "Escape") {
        e.preventDefault(); e.stopPropagation();
        var t = current.trigger; closePanel(); t.focus();
      } else if (key === "ArrowDown") { e.preventDefault(); move(1); }
      else if (key === "ArrowUp") { e.preventDefault(); move(-1); }
      else if (key === "Home") { e.preventDefault(); setActive(0); }
      else if (key === "End") { e.preventDefault(); setActive(current.items.length); }
      else if (key === "Enter" || (key === " " && !current.search)) {
        e.preventDefault(); e.stopPropagation(); choose(current.active);
      } else if (key === "Tab") { closePanel(); }
      else if (!current.search && key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
        var now = Date.now();
        current.typed = (now - current.typedAt > 700 ? "" : current.typed) + key.toLowerCase();
        current.typedAt = now;
        var hit = current.items.filter(function (li) {
          return !li.classList.contains("is-disabled") && li.textContent.trim().toLowerCase().indexOf(current.typed) === 0;
        })[0];
        if (hit) { setActive(current.items.indexOf(hit)); }
      }
    }, true);

    document.addEventListener("mousedown", function (e) {
      if (current && !current.panel.contains(e.target) && !current.trigger.contains(e.target)) {
        closePanel();
      }
    }, true);
    window.addEventListener("resize", function () { if (current) { place(); } });
    window.addEventListener("scroll", function (e) {
      if (!current) { return; }
      if (current.panel.contains(e.target)) { return; }
      place();
    }, true);

    // Scripts that set select.value / selectedIndex directly (no event) still update the display.
    ["value", "selectedIndex"].forEach(function (prop) {
      var desc = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, prop);
      if (!desc || !desc.set) { return; }
      Object.defineProperty(HTMLSelectElement.prototype, prop, {
        configurable: true,
        enumerable: desc.enumerable,
        get: desc.get,
        set: function (v) {
          desc.set.call(this, v);
          if (this._erpTrigger) { sync(this); }
        }
      });
    });

    document.addEventListener("reset", function (e) {
      setTimeout(function () {
        Array.prototype.forEach.call(e.target.querySelectorAll("select"), sync);
      }, 0);
    }, true);

    enhanceAll(document);
    var queued = false;
    var added = [];
    new MutationObserver(function (records) {
      records.forEach(function (r) {
        Array.prototype.forEach.call(r.addedNodes, function (n) {
          if (n.nodeType === 1) { added.push(n); }
        });
      });
      if (queued || !added.length) { return; }
      queued = true;
      requestAnimationFrame(function () {
        queued = false;
        var nodes = added; added = [];
        nodes.forEach(function (n) { if (n.isConnected) { enhanceAll(n); } });
      });
    }).observe(document.body, { childList: true, subtree: true });
    window.addEventListener("load", function () { enhanceAll(document); });
  }

  /* No saved-entry suggestions. Browsers (Edge / Chrome "Saved info", autofill) ignore autocomplete="off"
     on name, email, phone and address fields, so on top of the attribute these fields are kept read-only
     until you click into them (the browser only offers saved info to fields it can fill). The sign-in
     page (password manager) is left alone. */
  function noAutofill() {
    var LIKELY = /name|mail|phone|mobile|tel|address|street|city|country|state|zip|postal|po_box|emirate|passport|card|iban|birth|company|organi[sz]ation|license|licence|trn|tax|nationality|id_number|contact/i;
    var SKIP_TYPES = /^(password|hidden|checkbox|radio|file|submit|button|reset|image|color|range|date|datetime-local|time|month|week)$/;

    function labelText(el) {
      var text = "";
      if (el.id) {
        var l = document.querySelector('label[for="' + el.id.replace(/"/g, "") + '"]');
        if (l) { text = l.textContent; }
      }
      return text;
    }

    function likely(el) {
      var type = (el.getAttribute("type") || "text").toLowerCase();
      if (type === "email" || type === "tel") { return true; }
      return LIKELY.test([el.name, el.id, el.getAttribute("placeholder"), el.getAttribute("aria-label"), labelText(el)].join(" "));
    }

    function lockable(el) {
      return el.matches("input, textarea") && !el.readOnly && !el.disabled && !el.hasAttribute("data-erp-search") && !el.hasAttribute("data-erp-native");
    }

    function unlockAll(form) {
      Array.prototype.forEach.call(form.querySelectorAll("[data-erp-lock]"), function (el) {
        el.removeAttribute("readonly");
        el.removeAttribute("data-erp-lock");
      });
    }

    function prepare(el) {
      var type = (el.getAttribute("type") || "text").toLowerCase();
      if (SKIP_TYPES.test(type) || el.dataset.erpNoFill) { return; }
      var form = el.form;
      if (form && form.querySelector('input[type="password"]')) { return; }
      el.dataset.erpNoFill = "1";
      var strong = likely(el);
      el.setAttribute("autocomplete", strong ? "new-entry" : "off");
      if (!strong || !el.matches("input, textarea")) { return; }
      // type=email / tel are what the browser recognises best: show them as plain text boxes.
      if (type === "email") { el.setAttribute("inputmode", "email"); el.setAttribute("type", "text"); }
      if (type === "tel") { el.setAttribute("inputmode", "tel"); el.setAttribute("type", "text"); }
      if (!lockable(el)) { return; }
      el.setAttribute("readonly", "readonly");
      el.setAttribute("data-erp-lock", "1");
    }

    function fix(root) {
      var forms = root.matches && root.matches("form") ? [root] : [];
      if (root.querySelectorAll) { forms = forms.concat(Array.prototype.slice.call(root.querySelectorAll("form"))); }
      forms.forEach(function (form) {
        if (!form.querySelector('input[type="password"]')) { form.setAttribute("autocomplete", "off"); }
      });
      var fields = root.querySelectorAll ? Array.prototype.slice.call(root.querySelectorAll("input, textarea")) : [];
      if (root.matches && root.matches("input, textarea")) { fields.push(root); }
      fields.forEach(prepare);
    }

    // Click or Tab into a locked box: it becomes normal a moment later (after the browser has looked).
    document.addEventListener("focusin", function (e) {
      var el = e.target;
      if (!el || !el.getAttribute || el.getAttribute("data-erp-lock") !== "1") { return; }
      setTimeout(function () {
        el.removeAttribute("readonly");
        if (document.activeElement === el && el.setSelectionRange && /^(text|search|url)$/i.test(el.type || "text")) {
          var len = el.value.length;
          try { el.setSelectionRange(len, len); } catch (err) { /* ignore */ }
        }
      }, 30);
    }, true);
    document.addEventListener("focusout", function (e) {
      var el = e.target;
      if (el && el.getAttribute && el.getAttribute("data-erp-lock") === "1") { el.setAttribute("readonly", "readonly"); }
    }, true);
    // Saving: unlock everything first so "required" checks and the saved values work normally.
    document.addEventListener("click", function (e) {
      var b = e.target && e.target.closest ? e.target.closest('button, input[type="submit"]') : null;
      if (b && b.form) { unlockAll(b.form); }
    }, true);
    document.addEventListener("submit", function (e) { if (e.target && e.target.querySelectorAll) { unlockAll(e.target); } }, true);
    window.addEventListener("pageshow", function () { fix(document); });

    fix(document);
    var queued = false;
    var added = [];
    new MutationObserver(function (records) {
      records.forEach(function (r) {
        Array.prototype.forEach.call(r.addedNodes, function (n) { if (n.nodeType === 1) { added.push(n); } });
      });
      if (queued || !added.length) { return; }
      queued = true;
      requestAnimationFrame(function () {
        queued = false;
        var nodes = added; added = [];
        nodes.forEach(function (n) { if (n.isConnected) { fix(n); } });
      });
    }).observe(document.body, { childList: true, subtree: true });
  }

  /* Title Case for headings and labels. CSS "capitalize" would also capitalize "and", "of", "the" ...,
     so this small helper does it properly: every word starts with a capital letter except short joining
     words (a, an, the, and, or, of, in, on, to, by, for ...), which stay small unless they are the first or
     last word. Acronyms (TRN, VAT, AED), words with digits and words like iPhone are left as they are.
     It only touches headings, labels, column titles, tabs, menus and buttons - never table data, input
     values, help text or messages. window.erpTitleCase(text) can be used anywhere else. */
  var SMALL = ("a an the and but or nor for yet so as at by in of off on per to up via with from into onto over than vs").split(" ");
  var KEEP_LOWER = ("sq ft sqm kg km cm mm").split(" ");

  function titleCase(text, first, last) {
    var parts = String(text).split(/(\s+)/);   // words and the spaces between them
    var words = [];
    parts.forEach(function (part, i) { if (part && !/^\s+$/.test(part)) { words.push(i); } });
    var count = words.length;
    var afterBreak = false;
    words.forEach(function (index, n) {
      var token = parts[index];
      var isFirst = (n === 0 && first) || afterBreak;
      var isLast = n === count - 1 && last;
      parts[index] = token.split(/([\/])/).map(function (piece, k) {
        return fixWord(piece, isFirst && k === 0, isLast);
      }).join("");
      afterBreak = /[:\u2013\u2014]$/.test(token) || token === "-";
    });
    return parts.join("");
  }

  function fixWord(word, mustCapitalize, isLast) {
    var match = word.match(/^([^A-Za-z0-9]*)(.*?)([^A-Za-z0-9]*)$/);
    if (!match || !match[2]) { return word; }
    var lead = match[1], core = match[2], tail = match[3];
    if (/[0-9]/.test(core) || /^[A-Z]{2,}[a-z]?$/.test(core) || /[a-z][A-Z]/.test(core)) { return word; }
    if (/[A-Za-z]\.[A-Za-z]/.test(core)) { return word; }                       // e.g.
    var pieces = core.split("-").map(function (piece, k, arr) {
      var lower = piece.toLowerCase();
      if (!piece) { return piece; }
      if (/[A-Z]/.test(piece.slice(1))) { return piece; }                       // already has its own capitals
      if (KEEP_LOWER.indexOf(lower) !== -1) { return lower; }
      if (k === 0 && mustCapitalize) { return piece.charAt(0).toUpperCase() + piece.slice(1); }
      if (k === 0 && lead.indexOf("(") !== -1) { return piece.charAt(0).toUpperCase() + piece.slice(1); }
      var inner = k > 0 && k < arr.length - 1;                                  // year-to-date
      if (SMALL.indexOf(lower) !== -1 && (inner || (arr.length === 1 && !isLast))) { return lower; }
      return piece.charAt(0).toUpperCase() + piece.slice(1);
    });
    return lead + pieces.join("-") + tail;
  }
  window.erpTitleCase = titleCase;

  function titleCaseHeadings() {
    var INCLUDE = [
      "h1", "h2", "h3", "h4", "h5", "h6", "label", "legend", "caption", "summary", "dt",
      "thead th", "button", "a.button", "input[type=submit]",
      "nav a", "aside a", "header a", "[role=tab]", "[role=tablist] a", "[role=tablist] button",
      "[class*=breadcrumb] a", "[class*=breadcrumb] li", "[class*=title]", "[class*=heading]",
      ".erp-qbtn", "[class*=btn]", "[class*=button]", "[class*=label]",
      ".erp-fsel > span", ".erp-reports > span", ".erp-strip-label", ".erp-sum-label"
    ].join(",");
    var EXCLUDE = "td, tbody th, input, textarea, select, option, script, style, code, pre, .help, .helptext, " +
      ".messagelist, .errornote, .errorlist, [class*=toast], [class*=tooltip], [class*=help], [data-no-title-case], .erp-select-panel, .erp-select-label, .erp-info, svg, " +
      "[class*=material-symbols], .material-icons";

    function inside(el) {
      return el.closest && el.closest(EXCLUDE);
    }

    function fixElement(el) {
      if (inside(el)) { return; }
      var walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, null);
      var nodes = [];
      while (walker.nextNode()) { nodes.push(walker.currentNode); }
      nodes.forEach(function (node) {
        var parent = node.parentNode;
        if (!parent || !node.nodeValue || !/[A-Za-z]/.test(node.nodeValue)) { return; }
        if (parent !== el && inside(parent)) { return; }
        var tag = parent.nodeName;
        if (tag === "SCRIPT" || tag === "STYLE" || tag === "OPTION" || tag === "TEXTAREA") { return; }
        var first = !node.previousSibling || !/\S/.test(node.previousSibling.textContent || "");
        var last = !node.nextSibling || !/\S/.test(node.nextSibling.textContent || "");
        var fixed = titleCase(node.nodeValue, first, last);
        if (fixed !== node.nodeValue) { node.nodeValue = fixed; }
      });
    }

    function run(root) {
      if (!root || root.nodeType !== 1) { return; }
      if (root.matches && root.matches(INCLUDE)) { fixElement(root); }
      if (root.querySelectorAll) { Array.prototype.forEach.call(root.querySelectorAll(INCLUDE), fixElement); }
      var up = root.closest ? root.closest(INCLUDE) : null;   // text added inside an existing heading
      if (up) { fixElement(up); }
    }

    run(document.body);
    var queued = false;
    var added = [];
    new MutationObserver(function (records) {
      records.forEach(function (r) {
        Array.prototype.forEach.call(r.addedNodes, function (n) {
          added.push(n.nodeType === 1 ? n : n.parentNode);
        });
        if (r.type === "characterData" && r.target.parentNode) { added.push(r.target.parentNode); }
      });
      if (queued || !added.length) { return; }
      queued = true;
      requestAnimationFrame(function () {
        queued = false;
        var nodes = added; added = [];
        nodes.forEach(function (n) { if (n && n.isConnected) { run(n); } });
      });
    }).observe(document.body, { childList: true, subtree: true, characterData: true });
    window.addEventListener("load", function () { run(document.body); });
  }

  function init() {
    titleCaseHeadings();
    noAutofill();
    customSelects();
    fileWidgets();
    showToasts();
    sidebarMemory();
    deleteGuard();
    var form = document.querySelector('form[id$="_form"]');
    if (!form) {
      return;
    }
    addInfoIconsFromData(form);
    addInfoIcons(form);
    markRows(form);
    leaveGuard(form);
    popupCloseButton(form);
    if (form.id === "property_form") {
      propertyFormExtras(form);
    }
    if (form.id === "owner_form" || form.id === "tenant_form") {
      statusExtras(form);
    }
    window.addEventListener("scroll", hideTip, true);
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") {
        hideTip();
      }
    });
  }

  /* A form opened inside the pop-up window (View / Change / Add another owner ...): a "Close" button
     next to Save. It closes the pop-up the same way clicking outside it does. */
  function popupCloseButton(form) {
    var inFrame = false;
    try { inFrame = window.parent !== window; } catch (e) { inFrame = false; }
    var isPopup = inFrame || /[?&]_popup=/.test(location.search);
    if (!isPopup) { return; }
    var save = form.querySelector('[name="_save"]') || document.querySelector('[name="_save"]');
    if (!save || document.querySelector("[data-erp-popup-close]")) { return; }

    function closeIt() {
      if (inFrame) {
        try {
          var pdoc = window.parent.document;
          ["keydown", "keyup"].forEach(function (type) {
            pdoc.dispatchEvent(new window.parent.KeyboardEvent(type, { key: "Escape", code: "Escape", keyCode: 27, bubbles: true }));
          });
          // Still open? Click outside it (the backdrop), which also closes it.
          setTimeout(function () {
            if (window.parent && window.frameElement && window.frameElement.isConnected &&
                window.frameElement.offsetParent !== null) {
              var tall = pdoc.elementFromPoint(4, 4);
              if (tall) { tall.dispatchEvent(new window.parent.MouseEvent("click", { bubbles: true })); }
            }
          }, 150);
          return;
        } catch (err) { /* not reachable: fall through */ }
      }
      window.close();
    }

    var btn = document.createElement("button");
    btn.type = "button";
    btn.className = "erp-fbtn erp-popup-close";
    btn.setAttribute("data-erp-popup-close", "1");
    btn.textContent = "Close";
    btn.addEventListener("click", closeIt);
    save.parentNode.insertBefore(btn, save);
  }

  /* Icons are drawn by an icon font. While it downloads the browser would show the icon names
     ("dashboard", "chevron_right" ...) as text, so the CSS keeps the icons hidden and we reveal
     them once the font is ready (or after 2.5 s at the latest). */
  function iconsReady() {
    var root = document.documentElement;
    var done = false;
    function reveal() {
      if (!done) {
        done = true;
        root.classList.add("erp-icons-ready");
      }
    }
    var waiting = [];
    try {
      if (document.fonts && document.fonts.forEach) {
        document.fonts.forEach(function (face) {
          if (/material/i.test(String(face.family || ""))) {
            waiting.push(face.load());
          }
        });
      }
      if (!waiting.length && document.fonts && document.fonts.ready) {
        waiting.push(document.fonts.ready);
      }
    } catch (err) { /* fall through to the timer */ }
    Promise.all(waiting.map(function (p) { return Promise.resolve(p).catch(function () { return null; }); })).then(reveal);
    window.setTimeout(reveal, 2500);
  }
  iconsReady();

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();

/* The drawer handle: a small tab fixed at the middle of the left edge that opens and closes the side panel, so it is always
   in reach however far the page is scrolled. It presses Unfold's own button (kept in the page, hidden), so both behave the same. */
(function () {
  "use strict";
  function setUp() {
    var main = document.getElementById("main");
    // the button in the top bar (the side panel has one of its own for phones: that one is left alone)
    var original = main && main.querySelector('[x-on\\:click="sidebarToggle()"]');
    var panel = document.querySelector('[x-show="sidebarOpen"]');
    if (!original || !panel || document.querySelector(".erp-drawer")) { return; }
    var holder = original.parentElement;
    if (holder) {
      holder.classList.add("erp-drawer-original");
      var line = holder.nextElementSibling;  // the thin divider next to the old button
      if (line && line.classList.contains("w-px")) { line.classList.add("erp-drawer-original"); }
    }
    var handle = document.createElement("button");
    handle.type = "button";
    handle.className = "erp-drawer";
    var icon = document.createElement("span");
    icon.className = "material-symbols-outlined";
    handle.appendChild(icon);
    document.body.appendChild(handle);

    function place() {
      // sits on the right edge of the side panel when it is open (also when the panel lies over the page on a
      // narrow window), and on the left edge of the screen when it is closed
      var box = panel.getBoundingClientRect();
      var open = window.getComputedStyle(panel).display !== "none" && box.width > 20;
      var left = open ? Math.max(0, Math.round(box.right)) : 0;
      handle.style.left = Math.min(left, window.innerWidth - 24) + "px";
      icon.textContent = open ? "chevron_left" : "chevron_right";
      handle.setAttribute("aria-label", open ? "Hide the side panel" : "Show the side panel");
      handle.setAttribute("aria-expanded", open ? "true" : "false");
    }
    handle.addEventListener("click", function () {
      original.click();
      [0, 60, 150, 320, 600].forEach(function (ms) { window.setTimeout(place, ms); });
    });
    window.addEventListener("resize", place);
    if (window.ResizeObserver) { new ResizeObserver(place).observe(panel); }
    if (window.MutationObserver) { new MutationObserver(place).observe(panel, { attributes: true, attributeFilter: ["style", "class"] }); }
    place();
    window.setTimeout(place, 400);
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", setUp);
  } else {
    setUp();
  }
})();

/* The side panel stays docked (beside the page, open by default, choice remembered) from 1024 pixels wide, not only above
   1280 as Unfold has it. A laptop whose screen is scaled by Windows (1920 wide at 150% = 1280) then gets the same layout as
   a large monitor. Below 1024 (tablets, phones) the panel still floats over the page and starts closed. */
(function () {
  "use strict";
  var DOCK_FROM = 1024;
  function wide() { return window.innerWidth >= DOCK_FROM; }
  function stored() {
    try { return window.localStorage.getItem("sidebarOpen"); } catch (err) { return null; }
  }
  document.addEventListener("alpine:init", function () {
    var original = window.theme;
    if (typeof original !== "function" || original.erpWrapped) { return; }
    var wrapped = function () {
      var data = original.apply(this, arguments);
      data.sidebarOpen = function () {
        return wide() ? stored() !== "0" : false;
      };
      data.sidebarToggle = function () {
        var now = typeof this.sidebarOpen === "function" ? this.sidebarOpen() : this.sidebarOpen;
        this.sidebarOpen = !now;
        if (wide()) {
          try { window.localStorage.setItem("sidebarOpen", this.sidebarOpen ? "1" : "0"); } catch (err) { /* private window */ }
        }
      };
      if (data.themeBindings) {  // (Unfold re-decides this when the window is resized, and once when the page opens)
        data.themeBindings["x-resize.window"] = function () {
          this.sidebarOpen = wide() ? stored() !== "0" : false;
        };
      }
      return data;
    };
    wrapped.erpWrapped = true;
    window.theme = wrapped;
  });
})();


/* Map links (Google Maps and similar) always open in a new tab, everywhere in the app. */
(function () {
  "use strict";
  var MAP = /^https?:\/\/([a-z0-9-]+\.)*(maps\.app\.goo\.gl|goo\.gl\/maps|google\.[a-z.]+\/maps|maps\.google\.[a-z.]+|maps\.apple\.com|waze\.com|g\.page|share\.google)/i;

  function isMapLink(a) {
    var href = a.getAttribute("href") || "";
    return MAP.test(href) || !!a.closest("[class*=field-map_link], [class*=map-link]");
  }

  function mark(a) {
    if (a.getAttribute("target") !== "_blank") { a.setAttribute("target", "_blank"); }
    a.setAttribute("rel", "noopener noreferrer");
  }

  document.addEventListener("click", function (e) {
    var a = e.target && e.target.closest ? e.target.closest("a[href]") : null;
    if (a && isMapLink(a)) { mark(a); }
  }, true);

  function scan() {
    Array.prototype.forEach.call(document.querySelectorAll("a[href]"), function (a) { if (isMapLink(a)) { mark(a); } });
  }
  document.addEventListener("DOMContentLoaded", scan);
  window.addEventListener("load", scan);
})();
